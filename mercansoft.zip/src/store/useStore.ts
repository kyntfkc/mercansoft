import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppState, Model, Stone, StoneSet, CalculationResult } from '../types';

// Önceden tanımlanmış taş verileri
const predefinedStones: Omit<Stone, 'id'>[] = [
  // Beyaz Taşlar
  { name: "1.00 Beyaz", countPerGram: 540 },
  { name: "1.10 Beyaz", countPerGram: 430 },
  { name: "1.30 Beyaz", countPerGram: 270 },
  { name: "1.50 Beyaz", countPerGram: 170 },
  { name: "1.75 Beyaz", countPerGram: 110 },
  { name: "2.00 Beyaz", countPerGram: 75 },
  { name: "2.50 Beyaz", countPerGram: 41 },
  { name: "3.00 Beyaz", countPerGram: 25 },
  { name: "3.50 Beyaz", countPerGram: 17 },
  { name: "4.00 Beyaz", countPerGram: 11 },
  { name: "4.50 Beyaz", countPerGram: 8 },
  { name: "5.00 Beyaz", countPerGram: 6 },
  { name: "5.50 Beyaz", countPerGram: 4 },
  { name: "6.00 Beyaz", countPerGram: 3 },
  
  // Siyah Taşlar
  { name: "1.10 Siyah", countPerGram: 600 },
  { name: "1.30 Siyah", countPerGram: 380 },
  { name: "1.50 Siyah", countPerGram: 235 },
  
  // Aqua Taşlar
  { name: "1.10 Aqua", countPerGram: 430 },
  { name: "1.30 Aqua", countPerGram: 270 },
  { name: "1.50 Aqua", countPerGram: 170 },
  { name: "1.75 Aqua", countPerGram: 110 },
  { name: "2.00 Aqua", countPerGram: 75 },
  { name: "2.50 Aqua", countPerGram: 41 },
  
  // Ametist Taşlar
  { name: "1.10 Ametist", countPerGram: 430 },
  { name: "1.30 Ametist", countPerGram: 270 },
  { name: "1.50 Ametist", countPerGram: 170 },
  { name: "1.75 Ametist", countPerGram: 110 },
  { name: "2.00 Ametist", countPerGram: 75 },
  { name: "2.50 Ametist", countPerGram: 41 },
  
  // Pembe Taşlar
  { name: "1.10 Pembe", countPerGram: 430 },
  { name: "1.30 Pembe", countPerGram: 270 },
  { name: "1.50 Pembe", countPerGram: 170 },
  { name: "1.75 Pembe", countPerGram: 110 },
  { name: "2.00 Pembe", countPerGram: 75 },
  { name: "2.50 Pembe", countPerGram: 41 },
  
  // Lacivert Taşlar
  { name: "1.10 Lacivert", countPerGram: 660 },
  { name: "1.30 Lacivert", countPerGram: 400 },
  { name: "1.50 Lacivert", countPerGram: 250 },
  
  // Fuşya Taşlar
  { name: "1.10 Fuşya", countPerGram: 665 },
  { name: "1.30 Fuşya", countPerGram: 391 },
  { name: "1.50 Fuşya", countPerGram: 243 },
  
  // Yeşil Taşlar
  { name: "1.10 Yeşil", countPerGram: 780 },
  { name: "1.30 Yeşil", countPerGram: 485 },
  { name: "1.50 Yeşil", countPerGram: 310 },
  
  // Baget Taşlar
  { name: "2x1 Baget", countPerGram: 166 },
  { name: "2.5x1.5 Baget", countPerGram: 106 },
  { name: "3x2 Baget", countPerGram: 64 },
  { name: "4x2 Baget", countPerGram: 39 },
  { name: "5x2.5 Baget", countPerGram: 16 },
  
  // Damla Beyaz Taşlar
  { name: "3x2 Damla Beyaz", countPerGram: 53 },
  { name: "4x2 Damla Beyaz", countPerGram: 36 },
  { name: "5x3 Damla Beyaz", countPerGram: 16 },
  { name: "6x4 Damla Beyaz", countPerGram: 8 },
  { name: "7x5 Damla Beyaz", countPerGram: 4 },
  { name: "8x6 Damla Beyaz", countPerGram: 3 },
  
  // Damla Aqua Taşlar
  { name: "3x2 Damla Aqua", countPerGram: 53 },
  { name: "4x2 Damla Aqua", countPerGram: 36 },
  { name: "5x3 Damla Aqua", countPerGram: 16 },
  { name: "6x4 Damla Aqua", countPerGram: 8 },
  { name: "7x5 Damla Aqua", countPerGram: 4 },
  { name: "8x6 Damla Aqua", countPerGram: 3 },
  
  // Damla Ametist Taşlar
  { name: "3x2 Damla Ametist", countPerGram: 53 },
  { name: "4x2 Damla Ametist", countPerGram: 36 },
  { name: "5x3 Damla Ametist", countPerGram: 16 },
  { name: "6x4 Damla Ametist", countPerGram: 8 },
  { name: "7x5 Damla Ametist", countPerGram: 4 },
  { name: "8x6 Damla Ametist", countPerGram: 3 },
  
  // Oval Beyaz Taşlar
  { name: "3x2 Oval Beyaz", countPerGram: 50 },
  { name: "4x3 Oval Beyaz", countPerGram: 37 },
  { name: "5x3 Oval Beyaz", countPerGram: 12 },
  { name: "6x4 Oval Beyaz", countPerGram: 6 },
  { name: "7x5 Oval Beyaz", countPerGram: 4 },
  { name: "8x6 Oval Beyaz", countPerGram: 2.5 },
  
  // Mekik Beyaz Taşlar
  { name: "3x1.5 Mekik Beyaz", countPerGram: 85 },
  { name: "4x2 Mekik Beyaz", countPerGram: 43 },
  { name: "5x2.5 Mekik Beyaz", countPerGram: 23 },
  { name: "6x3 Mekik Beyaz", countPerGram: 13 },
  { name: "7x3.5 Mekik Beyaz", countPerGram: 9.5 },
  
  // Mekik Yeşil Taşlar
  { name: "3x1.5 Mekik Yeşil", countPerGram: 150 },
  { name: "4x2 Mekik Yeşil", countPerGram: 78 },
  { name: "5x2.5 Mekik Yeşil", countPerGram: 41 },
  
  // Kalp Taşlar
  { name: "4x4 Kalp Pembe", countPerGram: 11 },
  { name: "5x5 Kalp Pembe", countPerGram: 6 },
  { name: "4x4 Kalp Beyaz", countPerGram: 11 },
  { name: "5x5 Kalp Kırmızı", countPerGram: 9 },
  { name: "6x6 Kalp Kırmızı", countPerGram: 5 },
  
  // Oktagon Taşlar
  { name: "5x3 Oktagon Beyaz", countPerGram: 10 },
  { name: "6x4 Oktagon Beyaz", countPerGram: 5 },
  { name: "7x5 Oktagon Beyaz", countPerGram: 3 },
  { name: "8x6 Oktagon Beyaz", countPerGram: 2 },
  
  // Diğer Taşlar
  { name: "7x5 Oval Turuncu", countPerGram: 4 }
];

// Predefined stones'ın ID'lerle tamamlanmış hali
const stonesWithIds: Stone[] = predefinedStones.map(stone => ({
  ...stone,
  id: crypto.randomUUID()
}));

const initialState: AppState = {
  stones: stonesWithIds, // Önceden tanımlanmış taşlar
  models: [],
  stoneSets: [],
  selectedModelId: null,
  productionCount: 0,
  calculationResult: null,
};

export const useStore = create<
  AppState & {
    // Taş işlemleri
    addStone: (stone: Omit<Stone, 'id'>) => void;
    updateStone: (id: string, stone: Partial<Stone>) => void;
    deleteStone: (id: string) => void;

    // Model işlemleri
    addModel: (model: Omit<Model, 'id'>) => void;
    updateModel: (id: string, model: Partial<Model>) => void;
    deleteModel: (id: string) => void;

    // Taş seti işlemleri
    addStoneSet: (stoneSet: Omit<StoneSet, 'id'>) => void;
    updateStoneSet: (id: string, stoneSet: Partial<StoneSet>) => void;
    deleteStoneSet: (id: string) => void;

    // Hesaplama işlemleri
    setSelectedModelId: (id: string | null) => void;
    setProductionCount: (count: number) => void;
    calculateTotalWeight: () => void;

    // Veri işlemleri
    exportData: () => string;
    importData: (data: string) => void;
    resetStore: () => void;
  }
>(
  persist(
    (set, get) => ({
      ...initialState,

      // Taş işlemleri
      addStone: (stone) =>
        set((state) => ({
          stones: [...state.stones, { ...stone, id: crypto.randomUUID() }],
        })),
      updateStone: (id, stone) =>
        set((state) => ({
          stones: state.stones.map((s) => (s.id === id ? { ...s, ...stone } : s)),
        })),
      deleteStone: (id) =>
        set((state) => ({
          stones: state.stones.filter((s) => s.id !== id),
        })),

      // Model işlemleri
      addModel: (model) =>
        set((state) => ({
          models: [...state.models, { ...model, id: crypto.randomUUID() }],
        })),
      updateModel: (id, model) =>
        set((state) => ({
          models: state.models.map((m) => (m.id === id ? { ...m, ...model } : m)),
        })),
      deleteModel: (id) =>
        set((state) => ({
          models: state.models.filter((m) => m.id !== id),
        })),

      // Taş seti işlemleri
      addStoneSet: (stoneSet) =>
        set((state) => ({
          stoneSets: [...state.stoneSets, { ...stoneSet, id: crypto.randomUUID() }],
        })),
      updateStoneSet: (id, stoneSet) =>
        set((state) => ({
          stoneSets: state.stoneSets.map((s) => (s.id === id ? { ...s, ...stoneSet } : s)),
        })),
      deleteStoneSet: (id) =>
        set((state) => ({
          stoneSets: state.stoneSets.filter((s) => s.id !== id),
        })),

      // Hesaplama işlemleri
      setSelectedModelId: (id) => {
        set({ selectedModelId: id });
        // localStorage kullanımını azaltmak için hesaplama sonucunu temizle
        set({ calculationResult: null });
      },
      setProductionCount: (count) => set({ productionCount: count }),
      calculateTotalWeight: () => {
        const { stones, models, selectedModelId, productionCount } = get();

        if (!selectedModelId || productionCount <= 0) {
          set({ calculationResult: null });
          return;
        }

        const selectedModel = models.find((m) => m.id === selectedModelId);
        if (!selectedModel) {
          set({ calculationResult: null });
          return;
        }

        const stoneDetails = selectedModel.stones.map((modelStone) => {
          const stone = stones.find((s) => s.id === modelStone.stoneId);
          const quantity = modelStone.quantity * productionCount;
          // 1 gramda kaç adet taş olduğu bilgisinden tek taş ağırlığını hesapla
          const singleStoneWeight = stone ? (1 / stone.countPerGram) : 0;
          const totalWeight = singleStoneWeight * quantity;
          
          return {
            stoneId: modelStone.stoneId,
            stoneName: stone ? stone.name : 'Bilinmeyen Taş',
            quantity,
            totalWeight,
          };
        });

        const totalWeight = stoneDetails.reduce((sum, detail) => sum + detail.totalWeight, 0);

        const result: CalculationResult = {
          modelId: selectedModelId,
          modelName: selectedModel.name,
          productionCount,
          totalWeight,
          stoneDetails,
        };

        set({ calculationResult: result });
      },

      // Veri işlemleri
      exportData: () => {
        const { stones, models, stoneSets } = get();
        return JSON.stringify({ stones, models, stoneSets });
      },
      importData: (data) => {
        try {
          const parsed = JSON.parse(data);
          set({
            stones: parsed.stones || [],
            models: parsed.models || [],
            stoneSets: parsed.stoneSets || [],
          });
        } catch (e) {
          console.error('Veri içe aktarma hatası:', e);
        }
      },
      resetStore: () => set(initialState),
    }),
    {
      name: 'mercansoft-storage',
      // Sadece temel verileri persist et, hesaplama sonuçlarını etme
      partialize: (state) => ({
        stones: state.stones,
        models: state.models,
        stoneSets: state.stoneSets,
      }),
    }
  )
); 