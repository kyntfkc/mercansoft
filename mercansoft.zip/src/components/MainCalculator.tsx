'use client';

import { useEffect, useState, KeyboardEvent } from 'react';
import { 
  Box, 
  Typography, 
  FormControl, 
  TextField, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Divider,
  Autocomplete
} from '@mui/material';
import { useStore } from '../store/useStore';
import PrintIcon from '@mui/icons-material/Print';

// Model tipi tanımı
interface Model {
  id: string;
  name: string;
  stockCode?: string;
  category?: string;
  image?: string;
  stones: Array<{stoneId: string; quantity: number}>;
}

export default function MainCalculator() {
  const { 
    models, 
    stones, 
    selectedModelId, 
    productionCount, 
    calculationResult,
    setSelectedModelId, 
    setProductionCount, 
    calculateTotalWeight 
  } = useStore();

  // Görsel ve hesaplama sonucu gösterimi için durum
  const [showResults, setShowResults] = useState(false);
  
  // Üretim adedi için yerel durum
  const [localProductionCount, setLocalProductionCount] = useState<string>('');
  
  // Seçilen model için yerel durum
  const [selectedModel, setSelectedModel] = useState<Model | null>(null);

  // Varsayılan olarak boş değerler
  useEffect(() => {
    setSelectedModelId(null);
    setProductionCount(0);
  }, [setSelectedModelId, setProductionCount]);

  // Seçili modelin resim URL'sini al
  const selectedModelImage = models.find(m => m.id === selectedModelId)?.image;

  // Tek taş ağırlığını hesaplama fonksiyonu
  const calculateSingleStoneWeight = (countPerGram: number): number => {
    if (countPerGram <= 0) return 0;
    return 1 / countPerGram;
  };

  // Hesaplama butonuna tıklama olayı
  const handleCalculate = () => {
    if (selectedModelId && localProductionCount) {
      setProductionCount(Number(localProductionCount));
      calculateTotalWeight();
      setShowResults(true);
    }
  };
  
  // Enter tuşuna basıldığında hesapla
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleCalculate();
    }
  };

  // Yazdırma işlemi
  const handlePrint = () => {
    if (!calculationResult) return;
    
    // Yazdırma için yeni bir pencere aç
    const printWindow = window.open('', '_blank');
    
    if (!printWindow) {
      alert('Lütfen popup engelleyiciyi devre dışı bırakın');
      return;
    }
    
    // Fiş ayarlarını localStorage'dan al
    let settings;
    try {
      const savedSettings = localStorage.getItem('receiptSettings');
      settings = savedSettings ? JSON.parse(savedSettings) : null;
    } catch (error) {
      console.error('Fiş ayarları yüklenirken hata oluştu:', error);
      settings = null;
    }
    
    // Eğer kayıtlı ayar yoksa varsayılan değerleri kullan
    if (!settings) {
      settings = {
        title: 'MercanSoft',
        titleSize: 16,
        fontFamily: 'Arial',
        fontSize: 12,
        showTitle: true,
        showModel: true,
        titleBold: true,
        width: 50,
        minHeight: 100,
        showFooter: true,
        footerText: 'Bizi tercih ettiğiniz için teşekkür ederiz.',
        footerFontSize: 10,
        modelName: 'Test Modeli'
      };
    }
    
    // Profesyonel fiş içeriği - localStorage'daki ayarları kullan
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Taş Hesabı</title>
        <meta charset="utf-8">
        <style>
          @page {
            size: ${settings.width}mm ${settings.minHeight}mm;
            margin: 0;
          }
          body {
            font-family: ${settings.fontFamily};
            width: ${settings.width}mm;
            height: ${settings.minHeight}mm;
            margin: 0;
            padding: 4mm;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-sizing: border-box;
            background-color: #fbfbfb;
          }
          .content {
            text-align: center;
            border: 2px solid #ccdbe3;
            border-radius: 5px;
            padding: 5px;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.08);
            position: relative;
          }
          .content:before {
            content: '';
            position: absolute;
            top: 3px;
            left: 3px;
            right: 3px;
            bottom: 3px;
            border: 1px solid #e8f0f4;
            border-radius: 3px;
            pointer-events: none;
          }
          .logo {
            text-align: center;
            margin-bottom: 5px;
            font-size: ${settings.titleSize}px;
            color: #225C73;
            border-bottom: 1px dashed #dde9ef;
            padding-bottom: 5px;
            font-weight: ${settings.titleBold ? 'bold' : 'normal'};
          }
          .product-name {
            font-size: ${settings.fontSize + 1}px;
            margin: 6px 0;
            background-color: #f3f8fb;
            padding: 3px;
            border-radius: 3px;
            border: 1px solid #e0ebf2;
          }
          .info-container {
            display: flex;
            justify-content: space-between;
            margin: 6px 0;
            padding: 3px;
            border-radius: 3px;
            background-color: #f8fbfc;
          }
          .info-block {
            text-align: center;
            flex: 1;
            padding: 3px;
            border-radius: 3px;
          }
          .info-value {
            font-size: ${settings.fontSize + 4}px;
            font-weight: bold;
            margin-bottom: 2px;
            color: #225C73;
          }
          .info-label {
            font-size: ${settings.fontSize - 3}px;
            color: #666;
            text-transform: uppercase;
          }
          .footer {
            margin-top: 6px;
            font-size: ${settings.footerFontSize}px;
            color: #225C73;
            text-align: center;
            border-top: 1px dashed #dde9ef;
            padding-top: 4px;
            font-weight: 500;
          }
        </style>
      </head>
      <body>
        <div class="content">
          ${settings.showTitle ? `<div class="logo">${settings.title}</div>` : ''}
          
          ${settings.showModel ? 
            `<div class="product-name">${settings.modelName === 'Test Modeli' ? calculationResult.modelName : settings.modelName}</div>` : ''}
          
          <div class="info-container">
            <div class="info-block">
              <div class="info-value">${calculationResult.productionCount}</div>
              <div class="info-label">ADET</div>
            </div>
            
            <div class="info-block">
              <div class="info-value">${calculationResult.totalWeight.toFixed(2)}</div>
              <div class="info-label">TAŞ GRAMI</div>
            </div>
          </div>
          
          ${settings.showFooter ? `<div class="footer">${settings.footerText}</div>` : ''}
        </div>
      </body>
      </html>
    `;
    
    printWindow.document.open();
    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Yazdırma iletişim kutusunu açmadan önce sayfa yüklensin
    printWindow.onload = function() {
      printWindow.print();
    };
  };

  return (
    <Box sx={{ 
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }}>
      <Card sx={{ mb: 2, maxWidth: '450px', width: '100%' }}>
        <CardContent>
          <Typography variant="body1" fontWeight={500} gutterBottom>
            Model Seçimi ve Üretim Adedi
          </Typography>
          
          <Autocomplete
            id="model-autocomplete"
            options={models}
            getOptionLabel={(option) => option.name}
            filterOptions={(options, state) => {
              const inputValue = state.inputValue.toLowerCase().trim();
              return options.filter(
                option => 
                  option.name.toLowerCase().includes(inputValue) || 
                  (option.stockCode && option.stockCode.toLowerCase().includes(inputValue))
              );
            }}
            renderOption={(props, option) => {
              const { key, ...otherProps } = props;
              return (
                <li key={key} {...otherProps}>
                  <div>
                    <strong>{option.name}</strong>
                    {option.stockCode && (
                      <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                        Stok: {option.stockCode}
                      </Typography>
                    )}
                  </div>
                </li>
              );
            }}
            value={selectedModel}
            onChange={(_, newValue) => {
              setSelectedModel(newValue);
              setSelectedModelId(newValue?.id || null);
              setShowResults(false); // Model değiştiğinde sonuçları gizle
            }}
            renderInput={(params) => (
              <TextField 
                {...params}
                margin="dense"
                label="Model veya Stok Kodu ile Ara" 
                variant="outlined"
                size="small"
                sx={{ mb: 1 }}
                placeholder="Model adı veya stok kodu yazın..."
                onFocus={(e) => {
                  e.target.value = '';
                  setTimeout(() => {
                    const input = e.target as HTMLInputElement;
                    if (!input.value && document.activeElement === input) {
                      input.select();
                    }
                  }, 10);
                }}
              />
            )}
            noOptionsText="Model bulunamadı"
            size="small"
          />
          
          <TextField
            label="Üretim Adedi"
            type="text"
            fullWidth
            margin="dense"
            size="small"
            value={localProductionCount}
            onChange={(e) => {
              // Sadece sayıları kabul et
              const value = e.target.value.replace(/[^0-9]/g, '');
              setLocalProductionCount(value);
              setShowResults(false); // Üretim adedi değiştiğinde sonuçları gizle
            }}
            onKeyDown={handleKeyDown}
            placeholder="Üretim adedini girin"
            inputProps={{ 
              style: { 
                WebkitAppearance: 'none',
                MozAppearance: 'textfield'
              }
            }}
            helperText="Hesaplamak için Enter tuşuna basın"
            sx={{ mb: 0.5 }}
          />
          
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 1 }}>
            <Button 
              variant="contained" 
              color="secondary" 
              sx={{ 
                px: 4,
                py: 0.7,
                color: 'white',
                borderRadius: '20px',
                fontWeight: 600
              }}
              onClick={handleCalculate}
              disabled={!selectedModelId || !localProductionCount}
            >
              Hesapla
            </Button>
          </Box>
        </CardContent>
      </Card>

      {showResults && (
        <>
          <Grid container spacing={2} sx={{ width: '100%', maxWidth: '900px', mx: 'auto' }}>
            {/* Sol Sütun - Model Görseli */}
            <Grid item xs={12} md={5}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Typography variant="body1" fontWeight={500} gutterBottom>
                    Model Görseli
                  </Typography>
                  
                  {selectedModelImage ? (
                    <Box sx={{ 
                      p: 2, 
                      border: '1px solid',
                      borderColor: 'primary.light',
                      borderRadius: 2,
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      bgcolor: 'background.paper',
                      height: 'calc(100% - 50px)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <CardMedia
                        component="img"
                        sx={{ 
                          maxHeight: '220px', 
                          maxWidth: '100%',
                          objectFit: 'contain',
                          borderRadius: 1
                        }}
                        image={selectedModelImage}
                        alt="Model Görseli"
                      />
                    </Box>
                  ) : (
                    <Box 
                      sx={{ 
                        height: 'calc(100% - 50px)', 
                        minHeight: '220px',
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center', 
                        bgcolor: 'rgba(0,0,0,0.05)',
                        borderRadius: 1,
                        border: '1px dashed',
                        borderColor: 'divider'
                      }}
                    >
                      <Typography color="text.secondary" variant="body2">
                        Model görseli mevcut değil
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
            
            {/* Sağ Sütun - Hesaplama Sonucu */}
            <Grid item xs={12} md={7}>
              {calculationResult && (
                <Card sx={{ 
                  width: '100%',
                  height: '100%'
                }}>
                  <CardContent>
                    <Typography 
                      variant="h6" 
                      gutterBottom 
                      sx={{ 
                        textAlign: 'center', 
                        mb: 3, 
                        fontWeight: 700,
                        letterSpacing: '0.5px',
                        borderBottom: '2px solid',
                        borderColor: 'primary.light',
                        paddingBottom: 1,
                        position: 'sticky',
                        top: 0,
                        bgcolor: 'background.paper',
                        zIndex: 1
                      }}
                    >
                      Hesaplama Sonucu
                    </Typography>
                    
                    <Box sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      mb: 3,
                      p: 2,
                      borderRadius: 2,
                      bgcolor: 'rgba(153, 177, 191, 0.2)', 
                      boxShadow: '0 2px 8px rgba(34, 92, 115, 0.15)',
                      position: 'relative',
                      width: '100%',
                      maxWidth: { xs: '100%', sm: '80%' },
                      mx: 'auto'
                    }}>
                      <Typography variant="body2" color="primary.dark" fontWeight={500}>
                        Toplam Taş Gramı
                      </Typography>
                      <Typography 
                        variant="h4" 
                        fontWeight="bold" 
                        color="primary.main"
                        sx={{ mt: 0.5 }}
                      >
                        {calculationResult.totalWeight.toFixed(2)} gr
                      </Typography>
                    </Box>
                    
                    <Box 
                      sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: 2,
                        mb: 2,
                        justifyContent: 'center'
                      }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          p: 1.5,
                          borderRadius: 2,
                          border: '1px solid',
                          borderColor: 'divider',
                          width: 'calc(50% - 8px)',
                          minWidth: '140px',
                          flexGrow: 1,
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center'
                        }}
                      >
                        <Typography variant="body2" color="text.secondary" fontWeight={500}>
                          Model Adı
                        </Typography>
                        <Typography variant="h6" align="center" sx={{ mt: 0.5 }}>
                          {calculationResult.modelName}
                        </Typography>
                      </Paper>
                      
                      <Paper
                        elevation={0}
                        sx={{
                          p: 1.5,
                          borderRadius: 2,
                          border: '1px solid',
                          borderColor: 'divider',
                          width: 'calc(50% - 8px)',
                          minWidth: '140px',
                          flexGrow: 1,
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'center'
                        }}
                      >
                        <Typography variant="body2" color="text.secondary" fontWeight={500}>
                          Üretim Adedi
                        </Typography>
                        <Typography 
                          variant="h6" 
                          color="text.primary"
                          fontWeight="bold"
                          sx={{ mt: 0.5 }}
                        >
                          {calculationResult.productionCount}
                        </Typography>
                      </Paper>
                    </Box>
                  </CardContent>
                  
                  {/* Yazdırma Butonu - Yeni Konum */}
                  <Box sx={{ 
                    display: 'flex', 
                    justifyContent: 'center', 
                    mt: 2, 
                    mb: 2 
                  }}>
                    <Button
                      variant="contained"
                      startIcon={<PrintIcon />}
                      onClick={handlePrint}
                      sx={{
                        bgcolor: 'primary.main',
                        color: 'white',
                        borderRadius: '20px',
                        boxShadow: '0 4px 8px rgba(34, 92, 115, 0.3)',
                        px: 3,
                        py: 1,
                        fontWeight: 600,
                        '&:hover': {
                          bgcolor: 'primary.dark',
                          boxShadow: '0 6px 10px rgba(34, 92, 115, 0.4)',
                        }
                      }}
                    >
                      Yazdır
                    </Button>
                  </Box>
                </Card>
              )}
            </Grid>
          </Grid>

          {/* Taş Listesi - Ayrı Kart */}
          {calculationResult && calculationResult.stoneDetails.length > 0 && (
            <Card sx={{ 
              maxWidth: '650px', 
              width: '100%', 
              mt: 2, 
              mx: 'auto'
            }}>
              <CardContent>
                <Typography 
                  variant="h6" 
                  gutterBottom 
                  sx={{ 
                    textAlign: 'center', 
                    mb: 2, 
                    fontWeight: 600,
                    letterSpacing: '0.5px',
                    borderBottom: '2px solid',
                    borderColor: 'primary.light',
                    paddingBottom: 1
                  }}
                >
                  Taş Listesi
                </Typography>
                
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell width="70%">Taş Adı</TableCell>
                        <TableCell align="right" width="30%">Adet</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {calculationResult.stoneDetails.map((detail) => {
                        return (
                          <TableRow key={detail.stoneId}>
                            <TableCell 
                              sx={{ 
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                maxWidth: 0 // Bu maxWidth:0 ellipsis'in çalışması için gerekli
                              }}
                            >
                              {detail.stoneName}
                            </TableCell>
                            <TableCell align="right">{detail.quantity}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </Box>
  );
} 